﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HKeInvestWebApplication
{
    public partial class registrationpage : System.Web.UI.Page
    {

        protected void cvAccountNumber_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string temp = AccountNumber.Text.Trim();
            string LN = LastName.Text.Trim();
            if (LN != "" && temp != "")
            {
                LN = LN.ToUpper();
                //store first two letter from AccountNumber
                char[] arrr;
                arrr = temp.ToCharArray(0, 2);

                //store fist two letter in arr2 from last name
                char[] arr;
                arr = LN.ToCharArray(0, 2);

                if ((arrr[0] == arr[0] && arrr[1] == arr[1]) || (arrr[0] == arr[0] && arrr[1] == arr[0])) { return; }
            }
            args.IsValid = false;
            cvAccountNumber.ErrorMessage = "The account number does not match the client's last name";
        }
    }
}