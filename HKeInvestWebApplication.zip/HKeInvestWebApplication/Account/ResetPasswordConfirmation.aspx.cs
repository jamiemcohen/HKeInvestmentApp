﻿using System.Web.UI;

namespace HKeInvestWebApplication.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}